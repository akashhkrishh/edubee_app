import 'dart:async';
import 'dart:convert';
import 'package:edubee_app/data/models/question_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:edubee_app/controllers/usb_controller.dart';
import 'package:edubee_app/screens/results_screen.dart';
import 'package:edubee_app/screens/settings_screen.dart';
import 'package:edubee_app/services/background_music_service.dart';
import 'package:edubee_app/services/sound_service.dart';
import 'package:edubee_app/widgets/media_widget.dart';
import 'package:provider/provider.dart';
import 'package:edubee_app/providers/settings_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/foundation.dart';

class QuestionScreen extends StatefulWidget {
  final List<Question> questions;
  final bool isQuizMode;
  final int questionTimeLimit;
  final int? currentIndex;
  final int? score;
  final int? pausedTimeRemaining;
  final int? originalTotal;

  const QuestionScreen({
    super.key,
    required this.questions,
    this.isQuizMode = false,
    required this.questionTimeLimit,
    this.currentIndex,
    this.score,
    this.pausedTimeRemaining,
    this.originalTotal,
  });

  @override
  State<QuestionScreen> createState() => _QuestionScreenState();
}

// FIXED: Add WidgetsBindingObserver to listen for app lifecycle changes
class _QuestionScreenState extends State<QuestionScreen> with WidgetsBindingObserver {
  int _currentIndex = 0;
  late Question _currentQuestion;
  Timer? _timer;
  int _timerSeconds = 0;
  int? _selectedChoiceIndex;
  bool? _isCorrect;
  int _score = 0;
  final GlobalKey<MediaWidgetState> _mediaKey = GlobalKey<MediaWidgetState>();
  final BackgroundMusicService _musicService = BackgroundMusicService();
  late final SoundService _soundService;
  bool _hasAnswered = false;
  late final SettingsProvider _settingsProvider;
  StreamSubscription? _usbSubscription;
  bool _isPaused = false;
  late final int _totalQuestions;
  static const Duration _feedbackDuration = Duration(seconds: 2);

  @override
  void initState() {
    super.initState();
    _settingsProvider = Provider.of<SettingsProvider>(context, listen: false);
    _soundService = SoundService();
    _currentIndex = widget.currentIndex ?? 0;
    _currentQuestion = widget.questions[_currentIndex];
    _score = widget.score ?? 0;
    _timerSeconds = widget.pausedTimeRemaining ?? widget.questionTimeLimit;
    _totalQuestions = widget.originalTotal ?? widget.questions.length;

    if (widget.isQuizMode) {
      _startTimer(_timerSeconds);
    }
    HardwareKeyboard.instance.addHandler(_handleKeyEvent);
    _musicService.stopBackgroundMusic();

    // FIXED: Register this screen as a lifecycle observer
    WidgetsBinding.instance.addObserver(this);

    final usbController = Provider.of<UsbController>(context, listen: false);
    _usbSubscription = usbController.answerStream.listen((answerIndex) {
      if (mounted) {
        if (kDebugMode) {
          print('USB input received: answerIndex=$answerIndex');
        }
        _handleAnswer(answerIndex);
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    HardwareKeyboard.instance.removeHandler(_handleKeyEvent);
    if (_settingsProvider.isMusicEnabled) {
      _musicService.playBackgroundMusic();
    }
    _usbSubscription?.cancel();

    // FIXED: Remove the observer when the screen is disposed
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  // FIXED: Implement the method to handle lifecycle changes (app minimize, screen off, etc.)
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    switch (state) {
      case AppLifecycleState.inactive:
      case AppLifecycleState.paused:
      case AppLifecycleState.detached:
      // When app is minimized or screen is off, enter the pause state
      // to stop the timer and any media audio.
        if (!_isPaused) {
          _enterPauseState();
        }
        break;
      case AppLifecycleState.resumed:
      // When the app is resumed, ensure BGM is stopped immediately to
      // override the global handler in main.dart.
        _musicService.stopBackgroundMusic();
        break;
      default:
        break;
    }
  }

  void _pauseAllAudio() {
    _mediaKey.currentState?.stopPlayback();
  }

  void _resumeAllAudio() {
    _mediaKey.currentState?.resumePlayback();
  }

  void _enterPauseState() {
    if (!_isPaused) {
      setState(() {
        _isPaused = true;
        _timer?.cancel();
      });
      _pauseAllAudio();
    }
  }

  void _exitPauseState() {
    if (_isPaused) {
      setState(() {
        _isPaused = false;
        if (widget.isQuizMode) {
          _startTimer(_timerSeconds);
        }
      });
      _resumeAllAudio();
    }
  }

  Future<void> _savePausedState() async {
    if (!widget.isQuizMode) return;
    final prefs = await SharedPreferences.getInstance();
    final jsonList = widget.questions.map((q) => q.toJson()).toList();
    await prefs.setBool('is_paused', true);
    await prefs.setString('paused_questions_json', jsonEncode(jsonList));
    await prefs.setInt('current_index', _currentIndex);
    await prefs.setInt('score', _score);
    await prefs.setInt('paused_time', _timerSeconds);
    await prefs.setInt('original_total', _totalQuestions);
    await prefs.setInt('question_time_limit', widget.questionTimeLimit);
  }

  Future<void> _clearPausedState() async {
    if (!widget.isQuizMode) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('is_paused');
    await prefs.remove('paused_questions_json');
    await prefs.remove('current_index');
    await prefs.remove('score');
    await prefs.remove('paused_time');
    await prefs.remove('original_total');
    await prefs.remove('question_time_limit');
  }

  bool _handleKeyEvent(KeyEvent event) {
    if (event is KeyDownEvent && !_hasAnswered && !_isPaused) {
      if (event.logicalKey == LogicalKeyboardKey.digit1) {
        _handleAnswer(0);
        return true;
      } else if (event.logicalKey == LogicalKeyboardKey.digit2) {
        _handleAnswer(1);
        return true;
      }
    }
    return false;
  }

  void _startTimer([int? initialTime]) {
    _timerSeconds = initialTime ?? widget.questionTimeLimit;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || _isPaused) return;
      if (_timerSeconds > 0) {
        setState(() {
          _timerSeconds--;
        });
      } else {
        timer.cancel();
        _handleAnswer(null);
      }
    });
  }

  Future<bool> _onWillPop() async {
    _enterPauseState();
    final bool? shouldExit = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        if (widget.isQuizMode) {
          return AlertDialog(
            title: const Text('Exit Quiz?'),
            content: const Text('Your progress will be saved. You can resume later.'),
            actions: [
              // New button to navigate to the Settings page

              // Existing buttons
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: const Text('Save & Exit'),
              ),


            ],
          );
        } else {
          return AlertDialog(
            title: const Text('Exit Tutorial?'),
            content: const Text('Are you sure you want to return to the menu?'),
            actions: [
              TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Continue')),
              ElevatedButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Exit')),
            ],
          );
        }
      },
    );

    if (shouldExit == true) {
      if (widget.isQuizMode) {
        await _savePausedState();
      }
      return true;
    } else {
      _exitPauseState();
      return false;
    }
  }

  void _handleAnswer(int? choiceIndex) {
    if (_hasAnswered) return;
    _hasAnswered = true;
    _timer?.cancel();
    _mediaKey.currentState?.stopPlayback();

    if (!mounted) return;
    setState(() {
      _selectedChoiceIndex = choiceIndex;
      if (choiceIndex != null) {
        _isCorrect = _currentQuestion.isCorrect(choiceIndex);
        if (_isCorrect! && widget.isQuizMode) {
          _score++;
        }
      } else {
        _isCorrect = false;
      }
    });

    if (_settingsProvider.isSfxEnabled) {
      if (_isCorrect ?? false) {
        _soundService.playCorrectSound();
      } else {
        _soundService.playIncorrectSound();
      }
    }

    Future.delayed(_feedbackDuration, () {
      if (mounted) {
        _resetAndGoToNext();
      }
    });
  }

  void _openPauseMenu() {
    _enterPauseState();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text(widget.isQuizMode ? 'Quiz Paused' : 'Tutorial Paused'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _exitPauseState();
            },
            child: const Text('Resume'),
          ),

          if (widget.isQuizMode)
            TextButton(
              onPressed: () async {
                await _savePausedState();
                if(mounted) Navigator.of(context).popUntil((route) => route.isFirst);
              },
              child: const Text('Save & Exit'),
            )
          else
            TextButton(
              onPressed: () => Navigator.of(context).popUntil((route) => route.isFirst),
              child: const Text('Return to Home'),
            ),
          TextButton(
            onPressed: () {

              Navigator.push(context, MaterialPageRoute(builder: (context) => const SettingsScreen()));
            },
            child: const Text('Settings'),
          ),
        ],
      ),
    );
  }

  Color _getButtonColor(int choiceIndex) {
    const Color color1 = Color(0xFFFE6A00);
    const Color color2 = Color(0xFF00AEEF);
    final Color defaultColor = choiceIndex == 0 ? color1 : color2;

    if (!_hasAnswered) {
      return defaultColor;
    }

    final isCorrectChoice = _currentQuestion.isCorrect(choiceIndex);
    if (isCorrectChoice) {
      return Colors.green;
    } else if (_selectedChoiceIndex == choiceIndex) {
      return Colors.red;
    } else {
      return defaultColor.withOpacity(0.5);
    }
  }

  Future<void> _resetAndGoToNext() async {
    _timer?.cancel();
    _hasAnswered = false;

    if (_currentIndex < widget.questions.length - 1) {
      if (!mounted) return;
      setState(() {
        _currentIndex++;
        _currentQuestion = widget.questions[_currentIndex];
        _selectedChoiceIndex = null;
        _isCorrect = null;
        if (widget.isQuizMode) {
          _startTimer();
        }
      });
    } else {
      if (widget.isQuizMode) {
        await _clearPausedState();
        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => ResultsScreen(
                score: _score,
                totalQuestions: _totalQuestions,
              ),
            ),
          );
        }
      } else {
        if (mounted) {
          Navigator.pop(context);
        }
      }
    }
  }

  Widget _buildFeedbackIndicator() {
    if (_isCorrect == null) return const SizedBox(height: 70);
    final color = _isCorrect! ? Colors.green : Colors.red;
    final icon = _isCorrect! ? Icons.check_circle : Icons.cancel;
    final text = _isCorrect! ? 'Correct!' : 'Incorrect!';
    return Container(
      height: 70,
      margin: const EdgeInsets.symmetric(vertical: 20),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
          decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: color)
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: color, size: 24),
              const SizedBox(width: 10),
              Text(
                text,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHintButton() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: ElevatedButton.icon(
        onPressed: _hasAnswered
            ? null
            : () {
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: const Text('Hint'),
              content: Text(_currentQuestion.hint),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Got it'),
                ),
              ],
            ),
          );
        },
        icon: const Icon(Icons.lightbulb_outline),
        label: const Text('Show Hint'),
        style: ElevatedButton.styleFrom(
          foregroundColor: Theme.of(context).colorScheme.onSecondaryContainer,
          backgroundColor: Theme.of(context).colorScheme.secondaryContainer,
        ),
      ),
    );
  }

  Widget _buildAnswerButton(int choiceIndex) {
    final choiceText = choiceIndex == 0 ? _currentQuestion.choice1 : _currentQuestion.choice2;
    final buttonColor = _getButtonColor(choiceIndex);

    return ElevatedButton(
      onPressed: _hasAnswered ? null : () => _handleAnswer(choiceIndex),
      style: ElevatedButton.styleFrom(
        backgroundColor: buttonColor,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        elevation: 2,
        disabledBackgroundColor: buttonColor.withOpacity(0.8),
      ),
      child: Text(
        choiceText,
        textAlign: TextAlign.center,
        style: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (didPop) return;
        final shouldPop = await _onWillPop();
        if (shouldPop && mounted) {
          Navigator.of(context).pop();
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            widget.isQuizMode ? 'Question ${_currentIndex + 1} / $_totalQuestions' : 'Tutorial',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          backgroundColor: Colors.transparent,
          elevation: 0,
          actions: [
            if (widget.isQuizMode)
              Center(
                child: Padding(
                  padding: const EdgeInsets.only(right: 8.0),
                  child: Text(
                    '$_timerSeconds s',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            IconButton(
              icon: const Icon(Icons.pause, size: 28),
              onPressed: _openPauseMenu,
              tooltip: 'Pause',
            ),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: [
              if (widget.isQuizMode)
                LinearProgressIndicator(
                  value: (_currentIndex + 1) / _totalQuestions,
                  backgroundColor: theme.colorScheme.surfaceVariant,
                  minHeight: 8,
                ),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const SizedBox(height: 10),
                      Text(
                        _currentQuestion.question,
                        style: theme.textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 24),
                      MediaWidget(
                        key: _mediaKey,
                        question: _currentQuestion,
                      ),
                      const SizedBox(height: 24),

                      if (!widget.isQuizMode)
                        _buildHintButton()
                      else
                        const SizedBox.shrink(),

                      if (_hasAnswered)
                        _buildFeedbackIndicator()
                      else
                        SizedBox(height: widget.isQuizMode ? 70 : 0),

                      _buildAnswerButton(0),
                      const SizedBox(height: 16),
                      _buildAnswerButton(1),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}